/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doublylinkedlist;

/**
 *
 * @author ANSHUL
 */
public class EmployeeDoublyLinkedList 
{
    private EmployeeNode head, tail;
    private int size;

    public EmployeeDoublyLinkedList() 
    {
        this.head = this.tail = null;
    }
    
    public int getSize() 
    {
        return size;
    }

    public boolean isEmpty()
    {
        return head == null;
    }
    
    public void addToFront (Employee emp)
    {
        EmployeeNode newNode = new EmployeeNode(emp);
        
        if (isEmpty())
        {
            head = tail = newNode;
            size++;
        }
        else
        {
            newNode.setNext(head);
            head.setPrev(newNode);
            head = head.getPrev();
            size++;
        }
//        EmployeeNode node = new EmployeeNode(emp);
//
//        if (head == null) {
//            tail = node;
//        }
//        else {
//            head.setPrev(node);
//            node.setNext(head);
//        }
//
//        head = node;
//        size++;
    }
    
    public void addToEnd (Employee emp)
    {
        EmployeeNode newNode = new EmployeeNode(emp);
        
        if (isEmpty())
        {
            head = tail = newNode;
            size++;
        }
        else
        {
            tail.setNext(newNode);
            newNode.setPrev(tail);
            tail = tail.getNext();
            size++;
        }
//        EmployeeNode node = new EmployeeNode(emp);
//        if (tail == null) {
//            head = node;
//        }
//        else {
//            tail.setNext(node);
//            node.setPrev(tail);
//        }
//
//        tail = node;
//        size++;
    }
    
    public EmployeeNode removeFromFront() 
    {
        if (isEmpty()) 
        {
            return null;
        }

        EmployeeNode removedNode = head;
        head = head.getNext();
        size--;
        removedNode.setNext(null);
        head.setPrev(null);
        return removedNode;
    }
    
    public EmployeeNode removeFromEnd()
    {
        if (isEmpty())
        {
            return null;
        }
        
        EmployeeNode removedNode = tail;
        tail = tail.getPrev();
        tail.setNext(null);
        removedNode.setPrev(null);
        return removedNode;
    }
    
  
    public void addBefore (Employee newEmp, Employee existingEmp)
    {
        EmployeeNode newNode = new EmployeeNode (newEmp);
        
        if (isEmpty())
        {
            head = tail = newNode;
            System.out.println("List empty, head created");
            size++;
            return;
        }
        
        if (existingEmp == head.getEmp())
        {
            this.addToFront(newEmp);
            return;
        }
        
        EmployeeNode temp;
        for (temp = head; !temp.getEmp().equals(existingEmp) && temp != null; temp = temp.getNext());
        
        
        if (temp == null)
        {
            System.out.println("Node doesn't exist.");
            return;
        }
        
        newNode.setNext(temp);
        newNode.setPrev(temp.getPrev());
        temp.setPrev(newNode);
        newNode.getPrev().setNext(newNode);
        size++;
    }
    
    public void printList()
    {
        System.out.println("List ->");
        {
            for (EmployeeNode i = head; i != null; i = i.getNext())
            {
                System.out.println("" + i.toString());
            }
        }
    }
    
    public void printListReverse()
    {
        System.out.println("List Reverse ->");
        {
            for (EmployeeNode i = tail; i != null; i = i.getPrev())
            {
                System.out.println("" + i.toString());
            }
        }
    }
    
    
}
