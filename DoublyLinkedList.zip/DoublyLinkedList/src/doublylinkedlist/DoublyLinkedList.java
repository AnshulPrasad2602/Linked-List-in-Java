/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doublylinkedlist;

/**
 *
 * @author ANSHUL
 */
public class DoublyLinkedList 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Employee e1 = new Employee("Anshul", "Prasad", 11);
        Employee e2 = new Employee("Ria", "Singh", 56);
        Employee e3 = new Employee("Drishti", "Singh", 26);
        Employee e4 = new Employee("Gautam", "B", 27);
        Employee e5 = new Employee("Aryan", "Gupta", 16);

        EmployeeDoublyLinkedList list = new EmployeeDoublyLinkedList();
        
        System.out.println("\n" + list.isEmpty());
        
        list.addToFront(e1);
        list.addToFront(e2);
        list.addToEnd(e3);
        //list.addToEnd(new Employee ("Gautam", "B", 27));
        list.addToEnd(e4);
        list.addToFront(e5);
        
//        list.printList();
//        list.printListReverse();
//
//        list.removeFromEnd();
//        list.printList();
//        
//        list.removeFromFront();
//        list.printList();

        //list.addBefore(new Employee ("James", "Bond", 007), new Employee ("Gautam", "B", 027)); -> not work
        list.addBefore(new Employee ("James", "Bond", 007), e4);
        list.printList();
    }
    
}
